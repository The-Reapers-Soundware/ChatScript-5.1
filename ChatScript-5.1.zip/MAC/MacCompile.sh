g++  -funsigned-char src/*.cpp  -o LinuxChatScript  -lpthread 2>err.txt
